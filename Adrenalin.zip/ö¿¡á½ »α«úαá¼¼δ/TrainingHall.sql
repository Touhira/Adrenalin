Create database Training_Hall
Go 
Use Training_Hall

Create table Trainer
(
	id_trainer int primary key identity,
	F varchar(20) not null,
	I varchar(20) not null,
	O varchar(20) not null,
	Sex char not null,
	DateOfBirthday date not null,
	PhoneNumber varchar(20) not null unique,
	Login varchar(100) not null unique,
	Password varchar(100)not null,
	StartTime time not null, Constraint ch_ST check (StartTime >= '08:00' and StartTime <= '22:00'),
	FinishTime time not null, Constraint ch_FT check (FinishTime >= '08:00' and FinishTime <= '22:00')
)

Create table TypeAboniment
(
	id_type int primary key identity,
	NameAboniment varchar(30) not null,
	VisitCount int not null,
	Price money not null
)

Insert TypeAboniment
			Values ('�����������', 1, '10'), ('4 ����������', 4, '35'), ('8 ����������', 8, '65'), ('12 ����������', 12, '95')

Create table Client
(
	id_client int primary key identity,
	F varchar(20) not null,
	I varchar(20) not null,
	O varchar(20) not null,
	Sex char not null,Constraint ch_Sex check (Sex='M' Or Sex='W'),
	DateOfBirthday date not null,Constraint ch_DateOfBirthday check (DateOfBirthday<='2002-01-01'),
	PhoneNumber varchar(20) not null unique,
	Login varchar(100) not null unique,
	Password varchar(100)not null	
)
			
Create table Schedule
(
	id_schedule int primary key identity,
	id_trainer int not null, CONSTRAINT FK_Trainer FOREIGN KEY (id_trainer) REFERENCES Trainer (id_trainer) on update cascade on delete cascade,
	id_�lient int not null, CONSTRAINT FK2_Client FOREIGN KEY (id_�lient) REFERENCES Client (id_client) on update cascade on delete cascade,
	Comment varchar(max),
	isChecked int not null,
	VisitDate datetime not null, Constraint ch_VD check (Convert(time, VisitDate) >= '08:00'and Convert(time, VisitDate) <= '21:00')
)

Create table CancelType
(
	id int primary key identity,
	Name varchar(max) not null
)

insert into CancelType values('������������'), ('������')

Create table CancelTrain
(
	id int primary key identity,
	id_type int not null, CONSTRAINT FK_CancelType FOREIGN KEY (id_type) REFERENCES CancelType (id) on update cascade on delete cascade,
	id_schedule int not null, CONSTRAINT FK_Schedule FOREIGN KEY (id_schedule) REFERENCES Schedule (id_schedule) on update cascade on delete cascade,
	Comment varchar(max),
	isChecked int not null,
	CancelData datetime not null,
)

Create table Aboniment
(
	id_aboniment int primary key identity,
	id_type int not null, CONSTRAINT FK_TypeAboniment FOREIGN KEY (id_type) REFERENCES TypeAboniment (id_type) on update cascade on delete cascade,
	id_client int not null, CONSTRAINT FK_Client FOREIGN KEY (id_client) REFERENCES Client (id_client) on update cascade on delete cascade,
	PurchaseDate datetime not null
)

Create table TransactionType
(
	id int primary key identity,
	Name varchar(max)
)

insert into TransactionType values('�����������'), ('��������')

Create table Balance
(
	id int primary key identity,
	id_client int not null, CONSTRAINT FK_BalanceToClient FOREIGN KEY (id_client) REFERENCES Client (id_client) on update cascade on delete cascade,
	id_transaction int not null, CONSTRAINT FK_Transaction FOREIGN KEY (id_transaction) REFERENCES TransactionType (id) on update cascade on delete cascade,
	Count money not null,
)

go
create view TrainersView as 
	select * from Trainer

go
create view TypeAbonimentView as 
	select * from TypeAboniment

go
create view ClientView as 
	select * from Client

go
create view AbonimentView as 
	select * from Aboniment

go
create view ScheduleView as 
	select * from Schedule

go
create proc GetScheduleByTrainerTime
@id_trainer int,
@date datetime as
	select * from Schedule 
	where id_trainer = @id_trainer and VisitDate = @date

go
create proc GetScheduleByTrainerDate
@id_trainer int,
@date date as
	select * from Schedule
	where id_trainer = @id_trainer and Convert(date, VisitDate) = @date