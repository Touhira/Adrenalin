﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gym
{
    public class Trainer
    {
        public int id;
        public string f;
        public string i;
        public string o;
        public string Sex;
        public DateTime DateOfBirthday;
        public string PhoneNumber;
        public TimeSpan StartTime;
        public TimeSpan FinishTime;
        public string Login;
        public string Password;
    }

    public class TypeAboniment
    {
        public int id;
        public string Name;
        public int VisitCount;
        public decimal Price;
    }

    public class Client
    {
        public int id;
        public string f;
        public string i;
        public string o;
        public string Sex;
        public DateTime DateOfBirthday;
        public string PhoneNumber;
        public string Login;
        public string Password;
    }

    public class Aboniment
    {
        public int id;
        public int id_type;
        public int id_client;
        public DateTime PurchaseDate;
    }

    public class Schedule
    {
        public int id;
        public int id_trainer;
        public int id_client;
        public DateTime VisitDate;
        public string Comment;
        public int isChecked;
    }

    public class CancelType
    {
        public int id;
        public string Name;
    }

    public class CancelTrain
    {
        public int id;
        public int id_type;
        public int id_schedule;
        public DateTime VisitDate;
        public string Comment;
        public int isChecked;
        public Schedule Schedule;
    }

    public class TransactionType
    {
        public int id;
        public string Name;
    }

    public class Balance
    {
        public int id;
        public int id_client;
        public int id_transaction;
        public decimal Count;
    }
}
