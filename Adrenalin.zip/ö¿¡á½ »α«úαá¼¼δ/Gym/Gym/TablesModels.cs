﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gym
{
    public class TrainerModel
    {
        public void Update(Trainer trainer)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"UPDATE TrainersView SET F = '{trainer.f}', I = '{trainer.i}', O = '{trainer.o}', Sex = '{trainer.Sex}', DateOfBirthday = '{trainer.DateOfBirthday}', PhoneNumber = '{trainer.PhoneNumber}', StartTime = '{trainer.StartTime}', FinishTime = '{trainer.FinishTime}' WHERE id_trainer = {trainer.id}");
            }
        }

        public void Delete(Trainer trainer)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"DELETE TrainersView WHERE id_trainer = {trainer.id}");
            }
        }

        public void Insert(Trainer trainer)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"INSERT INTO TrainersView VALUES ('{trainer.f}', '{trainer.i}', '{trainer.o}', '{trainer.Sex}', '{trainer.DateOfBirthday}', '{trainer.PhoneNumber}', '{trainer.Login}', '{trainer.Password}', '{trainer.StartTime}', '{trainer.FinishTime}')");
            }
        }

        public IEnumerable<Trainer> Select()
        {
            var list = new List<Trainer>();

            using (var db = new DbController())
            {
                var reader = db.ExecuteReader("SELECT * FROM TrainersView");

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        list.Add(new Trainer()
                        {
                            id = reader.GetInt32(0),
                            f = reader.GetString(1),
                            i = reader.GetString(2),
                            o = reader.GetString(3),
                            Sex = reader.GetString(4),
                            DateOfBirthday = reader.GetDateTime(5),
                            PhoneNumber = reader.GetString(6),
                            Login = reader.GetString(7),
                            Password = reader.GetString(8),
                            StartTime = reader.GetTimeSpan(9),
                            FinishTime = reader.GetTimeSpan(10),
                        });
                    }
                }
            }

            return list;
        }
    }

    public class TypeAbonimentModel
    {
        public void Update(TypeAboniment type)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"UPDATE TypeAbonimentView SET NameAboniment = '{type.Name}', VisitCount = {type.VisitCount}, Price = '{type.Price}' WHERE id_trainer = {type.id}");
            }
        }

        public void Delete(TypeAboniment type)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"DELETE TypeAbonimentView WHERE id_type = {type.id}");
            }
        }

        public void Insert(TypeAboniment type)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"INSERT INTO TypeAbonimentView VALUES ('{type.Name}', {type.VisitCount}, '{type.Price}')");
            }
        }

        public IEnumerable<TypeAboniment> Select()
        {
            var list = new List<TypeAboniment>();

            using (var db = new DbController())
            {
                var reader = db.ExecuteReader("SELECT * FROM TypeAbonimentView");

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        list.Add(new TypeAboniment()
                        {
                            id = reader.GetInt32(0),
                            Name = reader.GetString(1),
                            VisitCount = reader.GetInt32(2),
                            Price = reader.GetDecimal(3)
                        });
                    }
                }
            }

            return list;
        }
    }

    public class ClientModel
    {
        public void Update(Client client)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"UPDATE ClientView SET F = '{client.f}', I = '{client.i}', O = '{client.o}', Sex = '{client.Sex}', DateOfBirthday = '{client.DateOfBirthday}', PhoneNumber = {client.PhoneNumber} WHERE id_client = {client.id}");
            }
        }

        public void Delete(Client client)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"DELETE ClientView WHERE id_client = {client.id}");
            }
        }

        public void Insert(Client client)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"INSERT INTO ClientView VALUES ('{client.f}', '{client.i}', '{client.o}', '{client.Sex}', '{client.DateOfBirthday}', '{client.PhoneNumber}', '{client.Login}', '{client.Password}')");
            }
        }

        public IEnumerable<Client> Select()
        {
            var list = new List<Client>();

            using (var db = new DbController())
            {
                var reader = db.ExecuteReader("SELECT * FROM ClientView");

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        list.Add(new Client()
                        {
                            id = reader.GetInt32(0),
                            f = reader.GetString(1),
                            i = reader.GetString(2),
                            o = reader.GetString(3),
                            Sex = reader.GetString(4),
                            DateOfBirthday = reader.GetDateTime(5),
                            PhoneNumber = reader.GetString(6),
                            Login = reader.GetString(7),
                            Password = reader.GetString(8)
                        });
                    }
                }
            }

            return list;
        }
    }

    public class AbonimentModel
    {
        public void Update(Aboniment abon)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"UPDATE AbonimentView SET id_type = {abon.id_type}, id_client = {abon.id_client}, PurchaseDate = '{abon.PurchaseDate}' WHERE id_trainer = {abon.id}");
            }
        }

        public void Delete(Aboniment abon)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"DELETE AbonimentView WHERE id_type = {abon.id}");
            }
        }

        public void Insert(Aboniment abon)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"INSERT INTO AbonimentView VALUES ({abon.id_type}, {abon.id_client}, '{abon.PurchaseDate}')");
            }
        }

        public IEnumerable<Aboniment> Select()
        {
            var list = new List<Aboniment>();

            using (var db = new DbController())
            {
                var reader = db.ExecuteReader("SELECT * FROM AbonimentView");

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        list.Add(new Aboniment()
                        {
                            id = reader.GetInt32(0),
                            id_type = reader.GetInt32(1),
                            id_client = reader.GetInt32(2),
                            PurchaseDate = reader.GetDateTime(3)
                        });
                    }
                }
            }

            return list;
        }
    }

    public class ScheduleModel
    {
        public void Update(Schedule sch)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"UPDATE ScheduleView SET VisitDate = '{sch.VisitDate}', Comment = '{sch.Comment}', isChecked = {sch.isChecked} WHERE id_schedule = {sch.id}");
            }
        }

        public void Delete(Schedule sch)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"DELETE ScheduleView WHERE id_schedule = {sch.id}");
            }
        }

        public void Insert(Schedule sch)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"INSERT INTO ScheduleView VALUES ({sch.id_trainer}, {sch.id_client}, '{sch.Comment}', {sch.isChecked}, '{sch.VisitDate}')");
            }
        }

        public IEnumerable<Schedule> Select()
        {
            var list = new List<Schedule>();

            using (var db = new DbController())
            {
                var reader = db.ExecuteReader("SELECT * FROM ScheduleView");

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        list.Add(new Schedule()
                        {
                            id = reader.GetInt32(0),
                            id_trainer = reader.GetInt32(1),
                            id_client = reader.GetInt32(2),
                            Comment = reader.GetString(3),
                            isChecked = reader.GetInt32(4),
                            VisitDate = reader.GetDateTime(5),
                        });
                    }
                }
            }

            return list;
        }

        public IEnumerable<Schedule> GetScheduleByTrainerTime(int id_trainer, DateTime date)
        {
            var list = new List<Schedule>();

            using (var db = new DbController())
            {
                var reader = db.ExecuteReader($"exec GetScheduleByTrainerTime {id_trainer}, '{date}'");

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        list.Add(new Schedule()
                        {
                            id = reader.GetInt32(0),
                            id_trainer = reader.GetInt32(1),
                            id_client = reader.GetInt32(2),
                            Comment = reader.GetString(3),
                            isChecked = reader.GetInt32(4),
                            VisitDate = reader.GetDateTime(5),
                        });
                    }
                }
            }

            return list;
        }

        public IEnumerable<Schedule> GetScheduleByTrainerDate(int id_trainer, DateTime date)
        {
            var list = new List<Schedule>();

            using (var db = new DbController())
            {
                var reader = db.ExecuteReader($"exec GetScheduleByTrainerDate {id_trainer}, '{date}'");

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        list.Add(new Schedule()
                        {
                            id = reader.GetInt32(0),
                            id_trainer = reader.GetInt32(1),
                            id_client = reader.GetInt32(2),
                            Comment = reader.GetString(3),
                            isChecked = reader.GetInt32(4),
                            VisitDate = reader.GetDateTime(5),
                        });
                    }
                }
            }

            return list;
        }
    }

    public class CancelTypeModel
    {
        public IEnumerable<CancelType> Select()
        {
            var list = new List<CancelType>();

            using (var db = new DbController())
            {
                var reader = db.ExecuteReader("SELECT * FROM CancelType");

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        list.Add(new CancelType()
                        {
                            id = reader.GetInt32(0),
                            Name = reader.GetString(1),
                        });
                    }
                }
            }

            return list;
        }
    }

    public class CancelModel
    {
        public void Update(CancelTrain sch)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"UPDATE CancelTrain SET isChecked = {sch.isChecked} WHERE id = {sch.id}");
            }
        }

        public void Delete(CancelTrain sch)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"DELETE CancelTrain WHERE id = {sch.id}");
            }
        }

        public void Insert(CancelTrain sch)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"INSERT INTO CancelTrain VALUES ({sch.id_type}, {sch.id_schedule}, '{sch.Comment}', {sch.isChecked}, '{sch.VisitDate}')");
            }
        }

        public IEnumerable<CancelTrain> Select()
        {
            var list = new List<CancelTrain>();
            var sm = new ScheduleModel();

            using (var db = new DbController())
            {
                var reader = db.ExecuteReader("SELECT * FROM CancelTrain");

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        list.Add(new CancelTrain()
                        {
                            id = reader.GetInt32(0),
                            id_type = reader.GetInt32(1),
                            id_schedule = reader.GetInt32(2),
                            Comment = reader.GetString(3),
                            isChecked = reader.GetInt32(4),
                            VisitDate = reader.GetDateTime(5),
                            Schedule = sm.Select().First(x => x.id == reader.GetInt32(2))
                        });
                    }
                }
            }

            return list;
        }        
    }

    public class TransactionTypeModel
    {
        public IEnumerable<TransactionType> Select()
        {
            var list = new List<TransactionType>();

            using (var db = new DbController())
            {
                var reader = db.ExecuteReader("SELECT * FROM TransactionType");

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        list.Add(new TransactionType()
                        {
                            id = reader.GetInt32(0),
                            Name = reader.GetString(1),
                        });
                    }
                }
            }

            return list;
        }
    }

    public class BalanceModel
    {
        public void Insert(Balance balance)
        {
            using (var db = new DbController())
            {
                db.ExecuteNonQueryCommand($"INSERT INTO Balance VALUES ({balance.id_client}, {balance.id_transaction}, '{balance.Count.ToString().Replace(',', '.')}')");
            }
        }

        public IEnumerable<Balance> Select()
        {
            var list = new List<Balance>();

            using (var db = new DbController())
            {
                var reader = db.ExecuteReader("SELECT * FROM Balance");

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        list.Add(new Balance()
                        {
                            id = reader.GetInt32(0),
                            id_client = reader.GetInt32(1),
                            id_transaction = reader.GetInt32(2),
                            Count = reader.GetDecimal(3)
                        });
                    }
                }
            }

            return list;
        }
    }
}