﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gym
{
    public partial class LoginForm : Form
    {
        ClientModel cm = new ClientModel();
        TrainerModel tm = new TrainerModel();

        private int regType { get; set; } = 1;

        public LoginForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                var clients = cm.Select().Where(x => x.Login == loginTB.Text && x.Password == passwordTB.Text).ToList();

                if (clients.Count > 0)
                {
                    GymForm gym = new GymForm(clients[0]);
                    gym.Show();
                }
                else
                {
                    MessageBox.Show("Ошибка. Неправильно введены данные!");
                }
            }
            else if(radioButton2.Checked)
            {
                var trainer = tm.Select().Where(x => x.Login == loginTB.Text && x.Password == passwordTB.Text).ToList();

                if (trainer.Count > 0)
                {
                    TrainerForm train = new TrainerForm(trainer[0]);
                    train.Show();
                }
                else
                {
                    MessageBox.Show("Ошибка. Неправильно введены данные!");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RegForm form = new RegForm(regType);
            form.ShowDialog();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked && radioButton2.Checked)
                radioButton1.Checked = false;

            regType = 2;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked && radioButton1.Checked)
                radioButton2.Checked = false;

            regType = 1;
        }

        private void F1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F1)
            {
                string pathDocument = AppDomain.CurrentDomain.BaseDirectory + "help.chm";
                System.Diagnostics.Process.Start(pathDocument);
            }
        }

        private void loginTB_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void passwordTB_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
