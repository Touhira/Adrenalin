﻿namespace Gym
{
    partial class GymForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GymForm));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.WritePage = new System.Windows.Forms.TabPage();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.writeDGV = new System.Windows.Forms.DataGridView();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SchedulePage = new System.Windows.Forms.TabPage();
            this.finishDTP = new System.Windows.Forms.DateTimePicker();
            this.startDTP = new System.Windows.Forms.DateTimePicker();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.scheduleDGV = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AbonimentPage = new System.Windows.Forms.TabPage();
            this.abonimentDGV = new System.Windows.Forms.DataGridView();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.VisitsLeftLabel = new System.Windows.Forms.Label();
            this.balancePage = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.notificationPage = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.notificationDGV = new System.Windows.Forms.DataGridView();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1.SuspendLayout();
            this.WritePage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.writeDGV)).BeginInit();
            this.SchedulePage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scheduleDGV)).BeginInit();
            this.AbonimentPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.abonimentDGV)).BeginInit();
            this.balancePage.SuspendLayout();
            this.notificationPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.notificationDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.WritePage);
            this.tabControl1.Controls.Add(this.SchedulePage);
            this.tabControl1.Controls.Add(this.AbonimentPage);
            this.tabControl1.Controls.Add(this.balancePage);
            this.tabControl1.Controls.Add(this.notificationPage);
            this.tabControl1.Location = new System.Drawing.Point(0, -2);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(594, 346);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.F1_KeyDown);
            // 
            // WritePage
            // 
            this.WritePage.BackColor = System.Drawing.Color.FloralWhite;
            this.WritePage.Controls.Add(this.dateTimePicker1);
            this.WritePage.Controls.Add(this.writeDGV);
            this.WritePage.Location = new System.Drawing.Point(4, 22);
            this.WritePage.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.WritePage.Name = "WritePage";
            this.WritePage.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.WritePage.Size = new System.Drawing.Size(586, 320);
            this.WritePage.TabIndex = 0;
            this.WritePage.Text = "Запись";
            this.WritePage.Enter += new System.EventHandler(this.WritePage_Enter);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(12, 26);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(151, 20);
            this.dateTimePicker1.TabIndex = 1;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // writeDGV
            // 
            this.writeDGV.AllowUserToAddRows = false;
            this.writeDGV.AllowUserToDeleteRows = false;
            this.writeDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.writeDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.writeDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column15,
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14});
            this.writeDGV.Location = new System.Drawing.Point(4, 63);
            this.writeDGV.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.writeDGV.Name = "writeDGV";
            this.writeDGV.ReadOnly = true;
            this.writeDGV.RowTemplate.Height = 24;
            this.writeDGV.Size = new System.Drawing.Size(578, 255);
            this.writeDGV.TabIndex = 0;
            this.writeDGV.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.writeDGV_CellDoubleClick);
            // 
            // Column15
            // 
            this.Column15.HeaderText = "Тренер";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.Width = 69;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "08:00";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 59;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "09:00";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 59;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "10:00";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 59;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "11:00";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 59;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "12:00";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 59;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "13:00";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 59;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "14:00";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 59;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "15:00";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Width = 59;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "16:00";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 59;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "17:00";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 59;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "18:00";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 59;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "19:00";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 59;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "20:00";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Width = 59;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "21:00";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            this.Column14.Width = 59;
            // 
            // SchedulePage
            // 
            this.SchedulePage.BackColor = System.Drawing.Color.MistyRose;
            this.SchedulePage.Controls.Add(this.finishDTP);
            this.SchedulePage.Controls.Add(this.startDTP);
            this.SchedulePage.Controls.Add(this.comboBox2);
            this.SchedulePage.Controls.Add(this.comboBox1);
            this.SchedulePage.Controls.Add(this.button3);
            this.SchedulePage.Controls.Add(this.button2);
            this.SchedulePage.Controls.Add(this.scheduleDGV);
            this.SchedulePage.Location = new System.Drawing.Point(4, 22);
            this.SchedulePage.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SchedulePage.Name = "SchedulePage";
            this.SchedulePage.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SchedulePage.Size = new System.Drawing.Size(586, 320);
            this.SchedulePage.TabIndex = 1;
            this.SchedulePage.Text = "Занятия";
            this.SchedulePage.Enter += new System.EventHandler(this.SchedulePage_Enter);
            // 
            // finishDTP
            // 
            this.finishDTP.Location = new System.Drawing.Point(434, 23);
            this.finishDTP.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.finishDTP.Name = "finishDTP";
            this.finishDTP.Size = new System.Drawing.Size(126, 20);
            this.finishDTP.TabIndex = 6;
            this.finishDTP.Visible = false;
            // 
            // startDTP
            // 
            this.startDTP.Location = new System.Drawing.Point(292, 23);
            this.startDTP.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.startDTP.Name = "startDTP";
            this.startDTP.Size = new System.Drawing.Size(128, 20);
            this.startDTP.TabIndex = 6;
            this.startDTP.Visible = false;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(292, 21);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(102, 21);
            this.comboBox2.TabIndex = 5;
            this.comboBox2.Visible = false;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "К определённому тренеру",
            "За период времени",
            "Все"});
            this.comboBox1.Location = new System.Drawing.Point(179, 21);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(102, 21);
            this.comboBox1.TabIndex = 4;
            this.comboBox1.SelectedValueChanged += new System.EventHandler(this.comboBox1_ValueChanged);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(16, 17);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(67, 27);
            this.button3.TabIndex = 2;
            this.button3.Text = "Отменить";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(94, 17);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(67, 27);
            this.button2.TabIndex = 2;
            this.button2.Text = "Печать";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // scheduleDGV
            // 
            this.scheduleDGV.AllowUserToAddRows = false;
            this.scheduleDGV.AllowUserToDeleteRows = false;
            this.scheduleDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.scheduleDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.scheduleDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.Column16,
            this.Column20});
            this.scheduleDGV.Location = new System.Drawing.Point(4, 63);
            this.scheduleDGV.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.scheduleDGV.Name = "scheduleDGV";
            this.scheduleDGV.ReadOnly = true;
            this.scheduleDGV.RowTemplate.Height = 24;
            this.scheduleDGV.Size = new System.Drawing.Size(578, 255);
            this.scheduleDGV.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Тренер";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // Column16
            // 
            this.Column16.HeaderText = "Дата";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            // 
            // Column20
            // 
            this.Column20.HeaderText = "ID";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            this.Column20.Visible = false;
            // 
            // AbonimentPage
            // 
            this.AbonimentPage.BackColor = System.Drawing.Color.AntiqueWhite;
            this.AbonimentPage.Controls.Add(this.abonimentDGV);
            this.AbonimentPage.Controls.Add(this.button1);
            this.AbonimentPage.Controls.Add(this.VisitsLeftLabel);
            this.AbonimentPage.Location = new System.Drawing.Point(4, 22);
            this.AbonimentPage.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.AbonimentPage.Name = "AbonimentPage";
            this.AbonimentPage.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.AbonimentPage.Size = new System.Drawing.Size(586, 320);
            this.AbonimentPage.TabIndex = 2;
            this.AbonimentPage.Text = "Абонимент";
            this.AbonimentPage.Enter += new System.EventHandler(this.AbonimentPage_Enter);
            // 
            // abonimentDGV
            // 
            this.abonimentDGV.AllowUserToAddRows = false;
            this.abonimentDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.abonimentDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.abonimentDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column21});
            this.abonimentDGV.Location = new System.Drawing.Point(4, 68);
            this.abonimentDGV.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.abonimentDGV.Name = "abonimentDGV";
            this.abonimentDGV.ReadOnly = true;
            this.abonimentDGV.RowTemplate.Height = 24;
            this.abonimentDGV.Size = new System.Drawing.Size(578, 252);
            this.abonimentDGV.TabIndex = 2;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "Название абонимента";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            // 
            // Column18
            // 
            this.Column18.HeaderText = "Кол-во занятий";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            // 
            // Column19
            // 
            this.Column19.HeaderText = "Стоимость";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            // 
            // Column21
            // 
            this.Column21.HeaderText = "id";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            this.Column21.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(448, 17);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 37);
            this.button1.TabIndex = 1;
            this.button1.Text = "Купить абонимент";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // VisitsLeftLabel
            // 
            this.VisitsLeftLabel.AutoSize = true;
            this.VisitsLeftLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.VisitsLeftLabel.Location = new System.Drawing.Point(15, 24);
            this.VisitsLeftLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.VisitsLeftLabel.Name = "VisitsLeftLabel";
            this.VisitsLeftLabel.Size = new System.Drawing.Size(157, 20);
            this.VisitsLeftLabel.TabIndex = 0;
            this.VisitsLeftLabel.Text = "Осталось занятий: ";
            // 
            // balancePage
            // 
            this.balancePage.BackColor = System.Drawing.Color.Azure;
            this.balancePage.Controls.Add(this.richTextBox1);
            this.balancePage.Controls.Add(this.button5);
            this.balancePage.Controls.Add(this.label3);
            this.balancePage.Controls.Add(this.label2);
            this.balancePage.Controls.Add(this.label1);
            this.balancePage.Location = new System.Drawing.Point(4, 22);
            this.balancePage.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.balancePage.Name = "balancePage";
            this.balancePage.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.balancePage.Size = new System.Drawing.Size(586, 320);
            this.balancePage.TabIndex = 4;
            this.balancePage.Text = "Баланс";
            this.balancePage.Enter += new System.EventHandler(this.BalancePage_Enter);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(271, 158);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(102, 19);
            this.richTextBox1.TabIndex = 5;
            this.richTextBox1.Text = "";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(282, 192);
            this.button5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(91, 36);
            this.button5.TabIndex = 4;
            this.button5.Text = "Пополнить";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(218, 161);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Сумма";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(217, 123);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Пополнить баланс:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(164, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(241, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Остаток на балансе:";
            // 
            // notificationPage
            // 
            this.notificationPage.BackColor = System.Drawing.Color.GhostWhite;
            this.notificationPage.Controls.Add(this.button4);
            this.notificationPage.Controls.Add(this.notificationDGV);
            this.notificationPage.Location = new System.Drawing.Point(4, 22);
            this.notificationPage.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.notificationPage.Name = "notificationPage";
            this.notificationPage.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.notificationPage.Size = new System.Drawing.Size(586, 320);
            this.notificationPage.TabIndex = 3;
            this.notificationPage.Text = "Уведомления";
            this.notificationPage.Enter += new System.EventHandler(this.notificationPage_Enter);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(20, 11);
            this.button4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 35);
            this.button4.TabIndex = 3;
            this.button4.Text = "Подробнее";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // notificationDGV
            // 
            this.notificationDGV.AllowUserToAddRows = false;
            this.notificationDGV.AllowUserToDeleteRows = false;
            this.notificationDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.notificationDGV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.notificationDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.notificationDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column23,
            this.Column24,
            this.Column25});
            this.notificationDGV.Location = new System.Drawing.Point(4, 56);
            this.notificationDGV.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.notificationDGV.Name = "notificationDGV";
            this.notificationDGV.ReadOnly = true;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.notificationDGV.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.notificationDGV.RowTemplate.Height = 24;
            this.notificationDGV.Size = new System.Drawing.Size(578, 262);
            this.notificationDGV.TabIndex = 2;
            // 
            // Column23
            // 
            this.Column23.HeaderText = "ID";
            this.Column23.Name = "Column23";
            this.Column23.ReadOnly = true;
            this.Column23.Visible = false;
            // 
            // Column24
            // 
            this.Column24.HeaderText = "Название";
            this.Column24.Name = "Column24";
            this.Column24.ReadOnly = true;
            // 
            // Column25
            // 
            this.Column25.HeaderText = "Дата";
            this.Column25.Name = "Column25";
            this.Column25.ReadOnly = true;
            this.Column25.Visible = false;
            // 
            // GymForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(590, 343);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "GymForm";
            this.Text = "Тренажёрный зал";
            this.tabControl1.ResumeLayout(false);
            this.WritePage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.writeDGV)).EndInit();
            this.SchedulePage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scheduleDGV)).EndInit();
            this.AbonimentPage.ResumeLayout(false);
            this.AbonimentPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.abonimentDGV)).EndInit();
            this.balancePage.ResumeLayout(false);
            this.balancePage.PerformLayout();
            this.notificationPage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.notificationDGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage WritePage;
        private System.Windows.Forms.TabPage SchedulePage;
        private System.Windows.Forms.DataGridView writeDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridView scheduleDGV;
        private System.Windows.Forms.TabPage AbonimentPage;
        private System.Windows.Forms.Label VisitsLeftLabel;
        private System.Windows.Forms.DataGridView abonimentDGV;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.DateTimePicker finishDTP;
        private System.Windows.Forms.DateTimePicker startDTP;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.TabPage notificationPage;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridView notificationDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        private System.Windows.Forms.TabPage balancePage;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
    }
}

