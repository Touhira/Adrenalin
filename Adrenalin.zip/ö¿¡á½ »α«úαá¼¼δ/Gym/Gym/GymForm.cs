﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace Gym
{
    public partial class GymForm : Form
    {
        private Client client { get; }
        private TrainerModel tm = new TrainerModel();
        private ScheduleModel sm = new ScheduleModel();
        private AbonimentModel am = new AbonimentModel();
        private TypeAbonimentModel tam = new TypeAbonimentModel();
        private CancelTypeModel ct = new CancelTypeModel();
        private ClientModel cm = new ClientModel();
        private CancelModel ctm = new CancelModel();
        private CancelTypeModel ctype = new CancelTypeModel();
        private BalanceModel bm = new BalanceModel();
        private TransactionTypeModel ttm = new TransactionTypeModel();
        private int VisitsLeft = 0;

        public GymForm(Client client)
        {
            InitializeComponent();

            try
            {
                this.client = client;
                var list = am.Select().Where(x => x.id_client == client.id).ToList();
                var schedule = sm.Select().Where(x => x.id_client == client.id).Count();
                var cancel = sm.Select().Where(x => x.id_client == client.id && ctm.Select().Where(y => y.id_schedule == x.id).Count() > 0).Count();

                foreach (var i in list)
                    VisitsLeft += tam.Select().Where(x => x.id == i.id_type).ToList()[0].VisitCount;

                VisitsLeft = VisitsLeft + cancel - schedule;

                if (VisitsLeft < 0) VisitsLeft = 0;

                Notification();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void WritePage_Enter(object sender, EventArgs e)
        {
            try
            {
                writeDGV.Rows.Clear();
                comboBox2.Items.Clear();

                var list = tm.Select().ToList();


                for (int i = 0; i < list.Count; i++)
                {
                    writeDGV.Rows.Add();

                    writeDGV[0, i].Value = $"{list[i].f} {list[i].i} {list[i].o}";
                    comboBox2.Items.Add($"{list[i].f} {list[i].i} {list[i].o}");

                    for (int j = 1; j < writeDGV.ColumnCount; j++)
                    {
                        var time = TimeSpan.Parse(writeDGV.Columns[j].HeaderText);
                        var schedule = sm.GetScheduleByTrainerTime(list[i].id, dateTimePicker1.Value.Date + time).ToList();

                        if (schedule.Count == 0 && list[i].StartTime <= time && list[i].FinishTime > time)
                            writeDGV[j, i].Value = "Записаться";
                        else if (schedule.Count > 0 && schedule.Count == ctm.Select().Where(x => x.Schedule.VisitDate == dateTimePicker1.Value.Date + time).Count())
                            writeDGV[j, i].Value = "Записаться";
                        else if (schedule.Count > 0)
                            writeDGV[j, i].Value = "";
                        else
                            writeDGV[j, i].Value = "Не работает";
                                                
                        if (dateTimePicker1.Value.Date + time < DateTime.Now.AddHours(1) && writeDGV[j, i].Value.ToString() == "Записаться")
                            writeDGV[j, i].Value = "Не работает";
                    }
                }

                Notification();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if(DateTime.Now > dateTimePicker1.Value)
            {
                dateTimePicker1.Value = DateTime.Now;
            }

            WritePage_Enter(sender, e);
            Notification();
        }

        private void writeDGV_CellDoubleClick(object sender, EventArgs e)// запись
        {
            try
            {
                Point point = new Point() { X = writeDGV.CurrentCellAddress.X, Y = writeDGV.CurrentCellAddress.Y };

                if ((string)writeDGV.CurrentCell.Value == "Записаться")
                {
                    if (VisitsLeft > 0)
                    {
                        var schedule = new Schedule()
                        {
                            id_trainer = tm.Select().Where(x => $"{x.f} {x.i} {x.o}" == (string)writeDGV[0, point.Y].Value).ToList()[0].id,
                            id_client = client.id,
                            VisitDate = dateTimePicker1.Value.Date + TimeSpan.Parse(writeDGV.Columns[point.X].HeaderText),
                            isChecked = 0
                        };

                        CommentForm form = new CommentForm(schedule);
                        form.ShowDialog();

                        if (form.isAdd)
                        {
                            VisitsLeft--;
                            WritePage_Enter(sender, e);
                        }
                    }
                    else if (VisitsLeft <= 0)
                    {
                        MessageBox.Show("У вас закончился абонимент!");
                    }
                }

                Notification();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SchedulePage_Enter(object sender, EventArgs e)
        {
            try
            {
                scheduleDGV.Rows.Clear();

                var list = sm.Select().Where(x => x.id_client == client.id && ctm.Select().Where(y => y.id_schedule == x.id).Count() == 0).ToList();

                for (int i = 0; i < list.Count; i++)
                {
                    scheduleDGV.Rows.Add();

                    var fio = tm.Select().Where(x => x.id == list[i].id_trainer).ToList()[0];

                    scheduleDGV[2, i].Value = list[i].id;
                    scheduleDGV[0, i].Value = $"{fio.f} {fio.i} {fio.o}";
                    scheduleDGV[1, i].Value = list[i].VisitDate;
                }

                Notification();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void AbonimentPage_Enter(object sender, EventArgs e)// остаток
        {
            try
            {
                VisitsLeftLabel.Text = "Занятий осталось: " + VisitsLeft;

                abonimentDGV.Rows.Clear();

                var list = tam.Select().ToList();

                for (int i = 0; i < list.Count; i++)
                {
                    abonimentDGV.Rows.Add();

                    abonimentDGV[0, i].Value = list[i].Name;
                    abonimentDGV[1, i].Value = list[i].VisitCount;
                    abonimentDGV[2, i].Value = Math.Round(list[i].Price, 2);
                    abonimentDGV[3, i].Value = list[i].id;
                }

                Notification();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BalancePage_Enter(object sender, EventArgs e)//баланс
        {
            var count_ent = bm.Select().Where(x => x.id_transaction == ttm.Select().First(y => y.Name == "Поступление").id && x.id_client == client.id).Sum(x => x.Count);
            var count_off = bm.Select().Where(x => x.id_transaction == ttm.Select().First(y => y.Name == "Списание").id && x.id_client == client.id).Sum(x => x.Count);

            label1.Text = $"Остаток на балансе: {Math.Round(count_ent - count_off, 2)} руб.";
        }

        private void button1_Click(object sender, EventArgs e)// покупка абонимента
        {
            try
            {
                var result = MessageBox.Show($"Вы уверены что хотите купить абонимент на {abonimentDGV[1, abonimentDGV.CurrentRow.Index].Value} занятия(-ий)?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    var price = tam.Select().First(x => x.id == Convert.ToInt32(abonimentDGV[3, abonimentDGV.CurrentRow.Index].Value)).Price;
                    var count_ent = bm.Select().Where(x => x.id_transaction == ttm.Select().First(y => y.Name == "Поступление").id && x.id_client == client.id).Sum(x => x.Count);
                    var count_off = bm.Select().Where(x => x.id_transaction == ttm.Select().First(y => y.Name == "Списание").id && x.id_client == client.id).Sum(x => x.Count);


                    if (price > count_ent - count_off)
                        throw new ArgumentException("Ошибка. Не хватает денег!");

                    am.Insert(new Aboniment()
                    {
                        id_type = tam.Select().Where(x => x.Name == (string)abonimentDGV[0, abonimentDGV.CurrentRow.Index].Value).ToList()[0].id,
                        id_client = client.id,
                        PurchaseDate = DateTime.Now
                    });

                    bm.Insert(new Balance()
                    {
                        id_client = client.id,
                        id_transaction = ttm.Select().First(x => x.Name == "Списание").id,
                        Count = price
                    });

                    VisitsLeft += (int)abonimentDGV[1, abonimentDGV.CurrentRow.Index].Value;
                    AbonimentPage_Enter(sender, e);
                }

                Notification();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                switch (comboBox1.Text)
                {
                    case "К определённому тренеру": PrintByTrainer(comboBox2.Text); break;
                    case "За период времени": PrintByTime(startDTP.Value, finishDTP.Value); break;
                    case "Все": AllPrint(); break;
                }
            }
            catch
            {
                MessageBox.Show("Ошибка! Вы ввели неверные значения");
            }

            Notification();
        }

        private void button3_Click(object sender, EventArgs e)// отмена тренировки
        {
            try
            {
                var cancel = new CancelTrain()
                {
                    id_schedule = Convert.ToInt32(scheduleDGV.CurrentRow.Cells[2].Value),
                    id_type = ct.Select().First(x => x.Name == "Пользователь").id,
                    isChecked = 0,
                    VisitDate = DateTime.Now
                };

                CommentForm form = new CommentForm(cancel, 2);
                form.ShowDialog();

                if (form.isAdd)
                {
                    VisitsLeft++;
                    WritePage_Enter(sender, e);
                }

                SchedulePage_Enter(sender, e);
            }
            catch
            {
                MessageBox.Show("Вы не выбрали занятие!");
            }

            Notification();
        }

        private void PrintByTrainer(string fio)// печать
        {
            try
            {
                Excel.Application excelApp = new Excel.Application();
                Excel.Workbook workbook;

                string path = $"{Environment.CurrentDirectory}/Templates/Trains.xlsx";
                workbook = excelApp.Workbooks.Open($"{Environment.CurrentDirectory}/Templates/Trains.xlsx");

                Excel.Worksheet worksheet = workbook.ActiveSheet;

                worksheet.Range["A1"].Value = $"{client.f} {client.i} {client.o}";
                worksheet.Range["D1"].Value = $"Остаток занятий на балансе: {VisitsLeft}";
                worksheet.Range["D1"].Style.Font.Size = 14;
                worksheet.Range["D1"].Style.HorizontalAlignment = HorizontalAlignment.Center;

                int row = 4;

                for (int i = 0; i < scheduleDGV.RowCount; i++)
                {
                    if (fio == scheduleDGV[0, i].Value.ToString())
                    {
                        SetCellBorders(row, 1, worksheet);
                        SetCellBorders(row, 2, worksheet);

                        worksheet.Range[$"B{row}"].Value = scheduleDGV[0, i].Value;
                        worksheet.Range[$"A{row}"].Value = scheduleDGV[1, i].Value;

                        row++;
                    }
                }

                excelApp.AlertBeforeOverwriting = true;

                if (File.Exists(path.Replace("Templates", "Documents")))
                    File.Delete(path.Replace("Templates", "Documents"));

                workbook.SaveAs($"{Environment.CurrentDirectory}/Documents/Trains.xlsx");
                workbook.Close(null, path, null);

                System.Diagnostics.Process.Start(path.Replace("Templates", "Documents"));
            }
            catch { MessageBox.Show("Документ до сих пор открыт. Для выполнения функции закройте его"); }
        }

        private void PrintByTime(DateTime start, DateTime finish)// печать
        {
            try
            {
                Excel.Application excelApp = new Excel.Application();
                Excel.Workbook workbook;

                string path = $"{Environment.CurrentDirectory}/Templates/Trains.xlsx";
                workbook = excelApp.Workbooks.Open($"{Environment.CurrentDirectory}/Templates/Trains.xlsx");

                Excel.Worksheet worksheet = workbook.ActiveSheet;

                worksheet.Range["A1"].Value = $"{client.f} {client.i} {client.o}";
                worksheet.Range["D1"].Value = $"Остаток занятий на балансе: {VisitsLeft}";
                worksheet.Range["D1"].Style.Font.Size = 14;
                worksheet.Range["D1"].Style.HorizontalAlignment = HorizontalAlignment.Center;

                int row = 4;

                for (int i = 0; i < scheduleDGV.RowCount; i++)
                {
                    if ((DateTime)scheduleDGV[1, i].Value >= start.Date && (DateTime)scheduleDGV[1, i].Value < finish.Date.AddDays(1))
                    {
                        SetCellBorders(row, 1, worksheet);
                        SetCellBorders(row, 2, worksheet);

                        worksheet.Range[$"B{row}"].Value = scheduleDGV[0, i].Value;
                        worksheet.Range[$"A{row}"].Value = scheduleDGV[1, i].Value;

                        row++;
                    }
                }

                excelApp.AlertBeforeOverwriting = true;

                if (File.Exists(path.Replace("Templates", "Documents")))
                    File.Delete(path.Replace("Templates", "Documents"));

                workbook.SaveAs($"{Environment.CurrentDirectory}/Documents/Trains.xlsx");
                workbook.Close(null, path, null);

                System.Diagnostics.Process.Start(path.Replace("Templates", "Documents"));
            }
            catch { MessageBox.Show("Документ до сих пор открыт. Для выполнения функции закройте его"); }
        }

        private void AllPrint()// печать
        {
            try
            {
                Excel.Application excelApp = new Excel.Application();
                Excel.Workbook workbook;

                string path = $"{Environment.CurrentDirectory}/Templates/Trains.xlsx";
                workbook = excelApp.Workbooks.Open($"{Environment.CurrentDirectory}/Templates/Trains.xlsx");

                Excel.Worksheet worksheet = workbook.ActiveSheet;

                worksheet.Range["A1"].Value = $"{client.f} {client.i} {client.o}";
                worksheet.Range["D1"].Value = $"Остаток занятий на балансе: {VisitsLeft}";
                worksheet.Range["D1"].Style.Font.Size = 14;
                worksheet.Range["D1"].Style.HorizontalAlignment = HorizontalAlignment.Center;

                int row = 4;

                for (int i = 0; i < scheduleDGV.RowCount; i++)
                {
                    SetCellBorders(row, 1, worksheet);
                    SetCellBorders(row, 2, worksheet);

                    worksheet.Range[$"B{row}"].Value = scheduleDGV[0, i].Value;
                    worksheet.Range[$"A{row}"].Value = scheduleDGV[1, i].Value;

                    row++;
                }

                excelApp.AlertBeforeOverwriting = true;

                if (File.Exists(path.Replace("Templates", "Documents")))
                    File.Delete(path.Replace("Templates", "Documents"));

                workbook.SaveAs($"{Environment.CurrentDirectory}/Documents/Trains.xlsx");
                workbook.Close(null, path, null);

                System.Diagnostics.Process.Start(path.Replace("Templates", "Documents"));
            }
            catch { MessageBox.Show("Документ до сих пор открыт. Для выполнения функции закройте его"); }
        }

        public void SetCellBorders(int rowNumber, int columnNumber, Excel.Worksheet _workSheet)
        {
            Excel.XlLineStyle lineStyle = Excel.XlLineStyle.xlContinuous;
            Excel.XlBorderWeight lineWeight = Excel.XlBorderWeight.xlThin;

            Excel.Range cellRange = (Excel.Range)_workSheet.Cells[rowNumber, columnNumber];
            Excel.Borders borders = cellRange.Borders;

            borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle = lineStyle;
            borders[Excel.XlBordersIndex.xlEdgeTop].Weight = lineWeight;

            borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = lineStyle;
            borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = lineWeight;

            borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle = lineStyle;
            borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = lineWeight;

            borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle = lineStyle;
            borders[Excel.XlBordersIndex.xlEdgeRight].Weight = lineWeight;
        }

        private void F1_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyData == Keys.F1)
                {
                    string pathDocument = AppDomain.CurrentDomain.BaseDirectory + "help.chm";
                    System.Diagnostics.Process.Start(pathDocument);
                }
            }
            catch { MessageBox.Show("Ошибка! Файл справки не найден."); }
        }

        private void comboBox1_ValueChanged(object sender, EventArgs e)
        {
            switch(comboBox1.Text)
            {
                case "К определённому тренеру": comboBox2.Visible = true; startDTP.Visible = false; finishDTP.Visible = false; break;
                case "За период времени": startDTP.Visible = true; finishDTP.Visible = true; comboBox2.Visible = false; break;
                case "Все": comboBox2.Visible = false; startDTP.Visible = false; finishDTP.Visible = false; break;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                CommentForm form = new CommentForm(notificationDGV.CurrentRow.Cells[0].Value, 3);
                form.ShowDialog();
            }
            catch { MessageBox.Show("Вы не выбрали уведомление!"); }
        }

        private void Notification()
        {
            var cancel_type = ctype.Select().First(x => x.Name == "Тренер").id;
            var cancels = ctm.Select().Where(x => x.id_type == cancel_type && x.Schedule.id_client == client.id && x.isChecked == 0);

            if (cancels.Count() > 0)
                notificationPage.Text = $"Уведомления({cancels.Count()})";
        }

        private void notificationPage_Enter(object sender, EventArgs e)
        {
            try
            {
                notificationDGV.Rows.Clear();

                var cancel_type = ctype.Select().First(x => x.Name == "Тренер").id;
                var cancels = ctm.Select().Where(x => x.id_type == cancel_type && x.Schedule.id_client == client.id).ToList();

                var counter = 0;

                for (int i = 0; i < cancels.Count; i++)
                {
                    notificationDGV.Rows.Add();
                    var trainer = tm.Select().First(x => x.id == sm.Select().First(y => y.id == cancels[i].id_schedule).id_trainer);
                    var fio = $"{trainer.f} {trainer.i} {trainer.o}";
                    cancels[i].isChecked = 1;

                    ctm.Update(cancels[i]);

                    notificationDGV[0, counter].Value = "cancel" + cancels[i].id;
                    notificationDGV[1, counter].Value = $"Тренер {fio} отменил тренировку на {cancels[i].VisitDate.ToString()} с комментарием {cancels[i].Comment}";
                    notificationDGV[2, counter].Value = cancels[i].VisitDate;

                    counter++;
                }

                notificationDGV.Sort(notificationDGV.Columns[2], ListSortDirection.Descending);

                notificationPage.Text = $"Уведомления";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)//Пополнение счета пользователя
        {
            try
            {
                bm.Insert(new Balance()
                {
                    id_client = client.id,
                    id_transaction = ttm.Select().First(x => x.Name == "Поступление").id,
                    Count = Convert.ToDecimal(richTextBox1.Text.Replace(',', '.'), CultureInfo.InvariantCulture)
                });

                MessageBox.Show("Баланс успешно пополнен!");

                BalancePage_Enter(sender, e);
            }
            catch
            {
                MessageBox.Show("Сумма введена некорректно!");
            }
        }
    }
}
