﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace Gym
{
    public partial class TrainerForm : Form
    {
        private Trainer trainer { get; }
        private TrainerModel tm = new TrainerModel();
        private ScheduleModel sm = new ScheduleModel();
        private AbonimentModel am = new AbonimentModel();
        private TypeAbonimentModel tam = new TypeAbonimentModel();
        private ClientModel cm = new ClientModel();
        private CancelModel ctm = new CancelModel();
        private CancelTypeModel ctype = new CancelTypeModel();

        public TrainerForm(Trainer trainer)
        {
            InitializeComponent();

            try
            {
                this.trainer = trainer;

                Notification();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Notification()
        {
            var cancel_type = ctype.Select().First(x => x.Name == "Пользователь").id;
            var cancels = ctm.Select().Where(x => x.id_type == cancel_type && x.Schedule.id_trainer == trainer.id && x.isChecked == 0);

            var count = sm.Select().Where(x => x.id_trainer == trainer.id && x.isChecked == 0).Count() + cancels.Count();
            
            if (count > 0)
                tabPage2.Text = $"Уведомления({count})";
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            try
            {
                dateTimePicker1_ValueChanged(sender, e);

                Notification();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            try
            {
                notificationDGV.Rows.Clear();

                var schedules = sm.Select().Where(x => x.id_trainer == trainer.id).ToList();
                var cancel_type = ctype.Select().First(x => x.Name == "Пользователь").id;
                var cancels = ctm.Select().Where(x => x.id_type == cancel_type && x.Schedule.id_trainer == trainer.id).ToList();

                var counter = 0;

                for (int i = 0; i < schedules.Count; i++)
                {
                    notificationDGV.Rows.Add();
                    var client = cm.Select().First(x => x.id == schedules[i].id_client);
                    var fio = $"{client.f} {client.i} {client.o}";
                    schedules[i].isChecked = 1;

                    sm.Update(schedules[i]);

                    notificationDGV[0, counter].Value = "schedule" + schedules[i].id;
                    notificationDGV[1, counter].Value = $"{fio} заказал новую тренировку на {schedules[i].VisitDate.ToString()} с комментарием {schedules[i].Comment}";
                    notificationDGV[2, counter].Value = schedules[i].VisitDate;

                    counter++;
                }

                for (int i = 0; i < cancels.Count; i++)
                {
                    notificationDGV.Rows.Add();
                    var client = cm.Select().First(x => x.id == sm.Select().First(y => y.id == cancels[i].id_schedule).id_client);
                    var fio = $"{client.f} {client.i} {client.o}";
                    cancels[i].isChecked = 1;

                    ctm.Update(cancels[i]);

                    notificationDGV[0, counter].Value = "cancel" + cancels[i].id;
                    notificationDGV[1, counter].Value = $"{fio} отменил тренировку на {cancels[i].Schedule.VisitDate.ToString()} с комментарием {cancels[i].Comment}";
                    notificationDGV[2, counter].Value = cancels[i].VisitDate;

                    counter++;
                }

                notificationDGV.Sort(notificationDGV.Columns[2], ListSortDirection.Descending);

                tabPage2.Text = $"Уведомления";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.Text == "На смену")
                {
                    dayDGV.Visible = true;
                    weekDGV.Visible = false;
                    dayDGV_Enter();
                }
                else if (comboBox1.Text == "На неделю")
                {
                    weekDGV.Visible = true;
                    dayDGV.Visible = false;
                    weekDGV_Enter();
                }
                else if (comboBox1.Text == "На месяц")
                {
                    weekDGV.Visible = true;
                    dayDGV.Visible = false;
                    monthDGV_Enter();
                }

                Notification();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.Text == "На смену")
                {
                    dayDGV_Enter();
                }
                else if (comboBox1.Text == "На неделю")
                {
                    weekDGV_Enter();
                }
                else if (comboBox1.Text == "На месяц")
                {
                    monthDGV_Enter();
                }

                Notification();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dayDGV_Enter()
        {
            try
            {
                dayDGV.Rows.Clear();

                dayDGV.Rows.Add();
                dayDGV.Rows.Add();

                var tr = tm.Select().Where(x => x.id == trainer.id).ToList()[0];

                dayDGV[0, 0].Value = $"{tr.f} {tr.i} {tr.o}";

                for (int i = 1; i < dayDGV.ColumnCount; i++)
                {
                    var time = TimeSpan.Parse(dayDGV.Columns[i].HeaderText);
                    var schedule = sm.GetScheduleByTrainerTime(trainer.id, dateTimePicker1.Value.Date + time).ToList();

                    if (schedule.Count > 0 && schedule.Count != ctm.Select().Where(x => x.Schedule.VisitDate == dateTimePicker1.Value.Date + time && x.Schedule.id_trainer == trainer.id).Count())
                    {
                        var fio = cm.Select().Where(x => x.id == schedule.Last().id_client).ToList()[0];
                        dayDGV[i, 0].Value = $"{fio.f} {fio.i.Substring(0, 1)}. {fio.o.Substring(0, 1)}.";
                        dayDGV[i, 1].Value = schedule.Last().id;
                    }
                }

                dayDGV.Rows[1].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void weekDGV_Enter()
        {
            try
            {
                weekDGV.Rows.Clear();
                weekDGV.Rows.Add();

                var start = (int)dateTimePicker1.Value.Date.DayOfWeek - 1;
                var finish = (int)dateTimePicker1.Value.Date.DayOfWeek - 1;

                weekDGV[0, 0].Value = $"{trainer.f} {trainer.i} {trainer.o}";

                for (int i = 1; i < weekDGV.Columns.Count; i++)
                {
                    if (i <= 7)
                    {
                        var day = (int)dateTimePicker1.Value.Date.DayOfWeek;

                        if (i < day)
                            weekDGV.Columns[i].HeaderText = dateTimePicker1.Value.Date.AddDays(-(day - i)).ToString().Substring(0, 10);
                        else if (i > day)
                            weekDGV.Columns[i].HeaderText = dateTimePicker1.Value.Date.AddDays((i - day)).ToString().Substring(0, 10);
                        else
                            weekDGV.Columns[i].HeaderText = dateTimePicker1.Value.Date.ToString().Substring(0, 10);

                        var cancel_count = ctm.Select().Where(x => x.Schedule.VisitDate.Date == Convert.ToDateTime(weekDGV.Columns[i].HeaderText) && x.Schedule.id_trainer == trainer.id).Count();
                        var schedule = sm.GetScheduleByTrainerDate(trainer.id, Convert.ToDateTime(weekDGV.Columns[i].HeaderText)).Count() - cancel_count;

                        weekDGV[i, 0].Value = schedule + " занятий(ия)";
                    }
                    else
                    {
                        weekDGV.Columns[i].Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void monthDGV_Enter()
        {
            try
            {
                weekDGV.Rows.Clear();
                weekDGV.Rows.Add();

                weekDGV[0, 0].Value = $"{trainer.f} {trainer.i} {trainer.o}";

                var days = DateTime.DaysInMonth(dateTimePicker1.Value.Year, dateTimePicker1.Value.Month);

                for (int i = 1; i < weekDGV.Columns.Count; i++)
                {
                    if (i <= days)
                    {
                        var day = i.ToString().Length == 1 ? $"0{i}" : i.ToString();
                        var month = dateTimePicker1.Value.Month.ToString().Length == 1 ? $"0{dateTimePicker1.Value.Month.ToString()}" : dateTimePicker1.Value.Month.ToString();
                        var date = $"{day}.{month}.{dateTimePicker1.Value.Year}";

                        weekDGV.Columns[i].HeaderText = date;
                        weekDGV.Columns[i].Visible = true;

                        var cancel_count = ctm.Select().Where(x => x.Schedule.VisitDate.Date == Convert.ToDateTime(weekDGV.Columns[i].HeaderText) && x.Schedule.id_trainer == trainer.id).Count();
                        var schedule = sm.GetScheduleByTrainerDate(trainer.id, Convert.ToDateTime(weekDGV.Columns[i].HeaderText)).Count() - cancel_count;

                        weekDGV[i, 0].Value = schedule + " занятий(ия)";
                    }
                    else
                    {
                        weekDGV.Columns[i].Visible = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Excel.Application excelApp = new Excel.Application();
                Excel.Workbook workbook;
                string path;

                if (comboBox1.Text == "На смену")
                {
                    path = $"{Environment.CurrentDirectory}/Templates/Day.xlsx";
                    workbook = excelApp.Workbooks.Open(path);

                    Excel.Worksheet worksheet = workbook.ActiveSheet;

                    worksheet.Range["A1"].Value = dayDGV[0, 0].Value;

                    var row = 4;

                    for (var i = 1; i < dayDGV.Columns.Count; i++)
                    {
                        if (dayDGV[i, 0].Value != null)
                        {
                            worksheet.Range[$"A{row}"].Value = dateTimePicker1.Value.ToString().Substring(0, 10);
                            worksheet.Range[$"B{row}"].Value = dayDGV.Columns[i].HeaderText;
                            worksheet.Range[$"C{row}"].Value = dayDGV[i, 0].Value;

                            row++;
                        }
                    }
                    
                    var delCount = 12 - (row - 4);

                    DeleteRows(15, delCount, worksheet);

                    excelApp.AlertBeforeOverwriting = true;

                    if (File.Exists(path.Replace("Templates", "Documents")))
                        File.Delete(path.Replace("Templates", "Documents"));

                    workbook.SaveAs($"{Environment.CurrentDirectory}/Documents/Day.xlsx");

                    workbook.Close(null, path, null);
                }
                else
                {
                    if (comboBox1.Text == "На неделю")
                    {
                        path = $"{Environment.CurrentDirectory}/Templates/Week.xlsx";
                        workbook = excelApp.Workbooks.Open(path);
                    }
                    else
                    {
                        path = $"{Environment.CurrentDirectory}/Templates/Month.xlsx";
                        workbook = excelApp.Workbooks.Open(path);
                    }

                    Excel.Worksheet worksheet = workbook.ActiveSheet;

                    worksheet.Range["A1"].Value = weekDGV[0, 0].Value;

                    var row = 4;

                    for (var i = 1; i < weekDGV.Columns.Count; i++)
                    {
                        if (weekDGV.Columns[i].Visible)
                        {
                            worksheet.Range[$"A{row}"].Value = weekDGV.Columns[i].HeaderText;
                            worksheet.Range[$"B{row}"].Value = weekDGV[i, 0].Value;

                            row++;
                        }
                    }

                    var days = DateTime.DaysInMonth(dateTimePicker1.Value.Year, dateTimePicker1.Value.Month);
                    var delCount = 31 - days;

                    DeleteRows(34, delCount, worksheet);

                    excelApp.AlertBeforeOverwriting = true;

                    if (File.Exists(path.Replace("Templates", "Documents")))
                        File.Delete(path.Replace("Templates", "Documents"));

                    if (comboBox1.Text == "На неделю")
                        workbook.SaveAs($"{Environment.CurrentDirectory}/Documents/Week.xlsx");
                    else
                        workbook.SaveAs($"{Environment.CurrentDirectory}/Documents/Month.xlsx");

                    workbook.Close(null, path, null);
                }

                excelApp.Quit();
                System.Diagnostics.Process.Start(path.Replace("Templates", "Documents"));
            }
            catch { MessageBox.Show("Документ до сих пор открыт. Для выполнения функции закройте его"); }
        }

        public void DeleteRows(int rowNum, int delCount, Excel.Worksheet _workSheet)
        {
            for (int i = 0; i < delCount; i++, rowNum--)
            {
                Excel.Range cellRange = (Excel.Range)_workSheet.Cells[rowNum, 1];
                Excel.Range _excelCells = (Excel.Range)_workSheet.get_Range($"A{rowNum}", $"B{rowNum}").Cells;
                _excelCells.EntireRow.Delete(Type.Missing);
            }
        }

        private void F1_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyData == Keys.F1)
                {
                    string pathDocument = AppDomain.CurrentDomain.BaseDirectory + "help.chm";
                    System.Diagnostics.Process.Start(pathDocument);
                }
            }
            catch { MessageBox.Show("Ошибка! Файл справки не найден."); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                CommentForm form = new CommentForm(notificationDGV.CurrentRow.Cells[0].Value, 3);
                form.ShowDialog();
            }
            catch { MessageBox.Show("Вы не выбрали уведомление!"); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                var id = dayDGV.CurrentRow.Cells[2].OwningColumn.HeaderText;

                var cancel = new CancelTrain()
                {
                    id_schedule = Convert.ToInt32(dayDGV[dayDGV.CurrentCell.ColumnIndex, 1].Value),
                    id_type = ctype.Select().First(x => x.Name == "Тренер").id,
                    isChecked = 0,
                    VisitDate = DateTime.Now
                };

                CommentForm form = new CommentForm(cancel, 2);
                form.ShowDialog();

                tabPage1_Click(sender, e);
            }
            catch
            {
                MessageBox.Show("Вы не выбрали занятие!");
            }
        }
    }
}
