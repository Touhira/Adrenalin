﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gym
{
    public partial class RegForm : Form
    {
        ClientModel cm = new ClientModel();
        TrainerModel tm = new TrainerModel();
        AbonimentModel am = new AbonimentModel();
        TypeAbonimentModel tam = new TypeAbonimentModel();

        public int regType { get; }

        public RegForm(int regType)
        {
            InitializeComponent();

            this.regType = regType;

            if (regType == 2)
            {
                label7.Visible = true;
                startTextBox.Visible = true;
                label8.Visible = true;
                finishTextBox.Visible = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (regType == 1)
            {
                try
                {
                    var clients = cm.Select().Where(x => x.Login == textBox1.Text).ToList();

                    if (clients.Count == 0)
                    {
                        cm.Insert(new Client()
                        {
                            f = f.Text,
                            i = i.Text,
                            o = o.Text,
                            Sex = sex.Text,
                            DateOfBirthday = date.Value,
                            PhoneNumber = phone.Text,
                            Login = textBox1.Text,
                            Password = textBox2.Text
                        });

                        am.Insert(new Aboniment()// P Z
                        {
                            id_type = tam.Select().First().id,
                            id_client = cm.Select().First(x => x.Login == textBox1.Text).id,
                            PurchaseDate = DateTime.Now
                        });

                        MessageBox.Show("Вы успешно зарегестрировались!");
                    }
                    else
                    {
                        MessageBox.Show("Ошибка. Пользователь уже существует!");
                    }
                }
                catch
                {
                    MessageBox.Show("Ошибка. Неправильно введены данные!");
                }
            }
            else if (regType == 2)
            {
                try
                {
                    var trainers = tm.Select().Where(x => x.Login == textBox1.Text).ToList();

                    if (trainers.Count == 0)
                    {
                        tm.Insert(new Trainer()
                        {
                            f = f.Text,
                            i = i.Text,
                            o = o.Text,
                            Sex = sex.Text,
                            DateOfBirthday = date.Value,
                            PhoneNumber = phone.Text,
                            StartTime = TimeSpan.Parse(startTextBox.Text),
                            FinishTime = TimeSpan.Parse(finishTextBox.Text),
                            Login = textBox1.Text,
                            Password = textBox2.Text
                        });

                        MessageBox.Show("Вы успешно зарегестрировались!");
                    }
                    else
                    {
                        MessageBox.Show("Ошибка. Пользователь уже существует!");
                    }
                }
                catch
                {
                    MessageBox.Show("Ошибка. Неправильно введены данные!");
                }
            }

            this.Close();
        }

        private void RegForm_Load(object sender, EventArgs e)
        {

        }
    }
}
