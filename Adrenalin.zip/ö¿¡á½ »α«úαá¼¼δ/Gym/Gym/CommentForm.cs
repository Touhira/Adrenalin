﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gym
{
    public partial class CommentForm : Form
    {
        ScheduleModel sm = new ScheduleModel();
        CancelModel cm = new CancelModel();
        
        private object Obj { get; set; }
        private int Type { get; set; }
        public bool isAdd { get; set; }

        public CommentForm(object obj, int type = 1)
        {
            InitializeComponent();

            Type = type;
            Obj = obj;

            if (type == 2)
            {
                button1.Text = "Подтвердить";
            }
            else if (type == 3)
            {
                var str = obj.ToString();
                var text = "";

                if (str.Contains("schedule"))
                {
                    text = sm.Select().First(x => x.id == Convert.ToInt32(str.Replace("schedule", ""))).Comment;
                }
                else
                {
                    text = cm.Select().First(x => x.id == Convert.ToInt32(str.Replace("cancel", ""))).Comment;
                }
                textBox1.Text = text;

                button1.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (Type == 1)
                {
                    var schedule = Obj as Schedule;
                    schedule.Comment = textBox1.Text;

                    var cancel_count = cm.Select().Where(x => x.Schedule.VisitDate.Date == schedule.VisitDate.Date && x.Schedule.id_trainer == schedule.id_trainer).Count();
                    var schedule_count = sm.GetScheduleByTrainerDate(schedule.id_trainer, schedule.VisitDate.Date).Count() - cancel_count;

                    if (schedule_count >= 12)
                        throw new ArgumentException("Тренер сегодня не принимает новые заявки!");

                    if (schedule.VisitDate < DateTime.Now)
                        throw new ArgumentException("Ошибка, невозможно добавить тренировку. Неправильно выбрано время!");

                    sm.Insert(schedule);
                }
                else if (Type == 2)
                {
                    var cancel = Obj as CancelTrain;
                    cancel.Comment = textBox1.Text;
                    cancel.Schedule = sm.Select().First(x => x.id == cancel.id_schedule);

                    if (cancel.Schedule.VisitDate.AddHours(-3) < DateTime.Now)
                        throw new ArgumentException("Ошибка, невозможно отменить тренировку. Тренировка уже закончилась/началась!");

                    cm.Insert(cancel);
                }

                isAdd = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                this.Close();
            }
        }
    }
}
